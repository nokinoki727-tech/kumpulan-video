const fs = require("fs");

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function testLoop() {
    for (let i = 1; i <= 10; i++) {
        console.log(`Respawn ke-${i}`);

        fs.writeFileSync("command.txt", "rose");

        // delay WAJIB biar AHK sempet proses
        await sleep(1500);
    }

    console.log("Test selesai");
}

testLoop();
