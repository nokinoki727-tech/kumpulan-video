const { WebcastPushConnection } = require("tiktok-live-connector");
const sound = require("sound-play");
const path = require("path");

// ================= CONFIG =================
const TIKTOK_USERNAME = "aseptzy888";
const audioPath = path.join(__dirname, "sound", "nigg.mp3");

const LIKE_PER_BATCH = 15;
const AUDIO_DURATION = 600; // ms
const ROSE_GIFT_ID = 5655;
// ==========================================

let batchQueue = 0;
let isPlaying = false;

// koneksi tiktok live
const tiktokLive = new WebcastPushConnection(TIKTOK_USERNAME);

tiktokLive.connect()
  .then(() => console.log("✅ Connected to TikTok Live"))
  .catch(err => console.error("❌ Gagal connect:", err));

// ================= GIFT ROSE =================
tiktokLive.on("gift", data => {
  if (!data.repeatEnd) return;
  if (data.giftId !== ROSE_GIFT_ID) return;

  console.log(`🌹 ${data.uniqueId} kirim Rose x${data.repeatCount}`);

  // 1 Rose = 1 batch (15 sound)
  batchQueue += data.repeatCount;

  console.log(`📦 Queue batch: ${batchQueue}`);

  if (!isPlaying) {
    processQueue();
  }
});

// ================= QUEUE SYSTEM =================
async function processQueue() {
  if (batchQueue <= 0) {
    isPlaying = false;
    console.log("🛑 Semua batch selesai");
    return;
  }

  isPlaying = true;
  batchQueue--;

  console.log(`🔊 Mainkan 1 batch | Sisa: ${batchQueue}`);

  await playSound15x();

  processQueue(); // lanjut batch berikutnya
}

// ================= SOUND =================
async function playSound15x() {
  for (let i = 1; i <= LIKE_PER_BATCH; i++) {
    console.log(`   🔔 Sound ke-${i}`);
    sound.play(audioPath);
    await new Promise(resolve => setTimeout(resolve, AUDIO_DURATION));
  }
}
