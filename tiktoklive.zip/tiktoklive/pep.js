const http = require('http');
const { exec } = require('child_process');

const PORT = 7777;
// Ganti dengan IP dan Port yang muncul di menu Wireless Debugging HP kamu
const TARGET_DEVICE = "192.168.1.243:37257"; 
const adbBase = `"C:\\platform-tools-latest-windows\\platform-tools\\adb.exe"`;

// Helper untuk kirim JSON response
const sendJson = (res, statusCode, payload) => {
    res.writeHead(statusCode, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(payload));
};

// Helper untuk menjalankan perintah ADB spesifik ke device
const adbExec = (command, callback) => {
    // Memastikan koneksi aktif sebelum eksekusi (opsional tapi disarankan)
    exec(`${adbBase} connect ${TARGET_DEVICE}`, () => {
        // Flag -s memastikan perintah hanya lari ke TARGET_DEVICE
        const fullCommand = `${adbBase} -s ${TARGET_DEVICE} ${command}`;
        exec(fullCommand, callback);
    });
};

const server = http.createServer((req, res) => {
    if (req.method !== 'POST') {
        return sendJson(res, 405, { status: "Error", message: 'Gunakan method POST!' });
    }

    let body = '';
    req.on('data', chunk => { body += chunk.toString(); });

    req.on('end', () => {
        let data;
        try {
            data = JSON.parse(body);
        } catch (e) {
            return sendJson(res, 400, { status: 'Error', message: 'Format JSON tidak valid' });
        }

        const pkg = data.package_name;

        // --- LOGIKA PERINTAH ---

        if (data.action === 'go_home') {
            adbExec(`shell am start -a android.intent.action.MAIN -c android.intent.category.HOME`, (err) => {
                if (err) return sendJson(res, 500, { status: 'Error', message: 'Gagal ke Home', detail: err.message });
                console.log(`[${TARGET_DEVICE}] Berhasil: Back to Home`);
                sendJson(res, 200, { status: 'Success', message: 'HP kembali ke Home' });
            });
        } 

        else if (data.action === 'uninstall_app') {
            if (!pkg) return sendJson(res, 400, { status: 'Fail', message: 'Package name kosong!' });
            
            adbExec(`shell "am force-stop ${pkg} && pm uninstall --user 0 ${pkg}"`, (err) => {
                if (err) return sendJson(res, 500, { status: 'Error', message: `Gagal hapus ${pkg}` });
                console.log(`[${TARGET_DEVICE}] Berhasil: Uninstall ${pkg}`);
                sendJson(res, 200, { status: 'Success', message: `Aplikasi ${pkg} dicopot!` });
            });
        }

        else if (data.action === 'reset_app') {
            if (!pkg) return sendJson(res, 400, { status: 'Fail', message: 'Package name kosong!' });
            
            // Step 1: Force stop
            adbExec(`shell am force-stop ${pkg}`, (err) => {
                if (err) return sendJson(res, 500, { status: 'Error', message: `Gagal stop ${pkg}` });
                
                // Step 2: Launch ulang
                adbExec(`shell monkey -p ${pkg} -c android.intent.category.LAUNCHER 1`, (err2) => {
                    if (err2) return sendJson(res, 500, { status: 'Error', message: `Gagal restart ${pkg}` });
                    console.log(`[${TARGET_DEVICE}] Berhasil: Restart ${pkg}`);
                    sendJson(res, 200, { status: 'Success', message: `Aplikasi ${pkg} direstart!` });
                });
            });
        }

        else if (data.action === 'open_app') {
            if (!pkg) return sendJson(res, 400, { status: 'Fail', message: 'Package name kosong!' });
            
            adbExec(`shell monkey -p ${pkg} -c android.intent.category.LAUNCHER 1`, (err) => {
                if (err) return sendJson(res, 500, { status: 'Error', message: `Gagal buka ${pkg}` });
                console.log(`[${TARGET_DEVICE}] Berhasil: Buka ${pkg}`);
                sendJson(res, 200, { status: 'Success', message: `Aplikasi ${pkg} terbuka!` });
            });
        }

        else {
            sendJson(res, 400, { status: 'Fail', message: 'Action tidak dikenal' });
        }
    });
});

server.listen(PORT, '0.0.0.0', () => {
    console.log('=========================================');
    console.log(`Server JALAN di http://localhost:${PORT}`);
    console.log(`Target HP   : ${TARGET_DEVICE}`);
    console.log(`ADB Path    : ${adbBase}`);
    console.log('=========================================');
});