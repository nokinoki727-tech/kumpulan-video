F8::
Send, {Esc}
Sleep, 300
Send, r
Sleep, 200
Click, 900, 520
return