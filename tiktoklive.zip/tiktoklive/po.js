const { WebcastPushConnection } = require("tiktok-live-connector");
const sound = require("sound-play");
const path = require("path");

const TIKTOK_USERNAME = "jordy.el.gasing";

const AUDIO_FAHS = path.join(__dirname, "sound", "fahh.mp3");

const ROSE_GIFT_ID = 5655;
const CORGY = 6267;
const HAND = 5660;
const DOUGH = 5879;
const HAT = 6427;
const GUN = 7168;
const ME = 7934;
const PAUS = 6820;
const CONFETTI = 5585;

const tiktokLive = new WebcastPushConnection(TIKTOK_USERNAME);

tiktokLive.connect()
  .then(() => console.log("✅ Connected to TikTok Live"))
  .catch(err => console.error("❌ Gagal connect:", err));

async function playFah() {
  try {
    await sound.play(AUDIO_FAHS);
  } catch (err) {
    console.error("❌ Gagal play audio:", err);
  }
}

const queue = [];
let isProcessing = false;

// fungsi delay (biar presisi)
const delay = (ms) => new Promise(res => setTimeout(res, ms));

// fungsi untuk nambah task ke queue
function addToQueue(task) {
    queue.push(task);
    processQueue();
}

let donutQueue = [];
let isProcessingDonut = false;

async function processDonutQueue() {
  if (isProcessingDonut) return;
  if (donutQueue.length === 0) return;

  isProcessingDonut = true;

  const totalTrigger = donutQueue.shift();
  console.log("🎯 Processing Donut:", totalTrigger);

  for (let i = 1; i <= totalTrigger; i++) {
    await new Promise(resolve => setTimeout(resolve, 1000)); // delay biar stabil

    await playFah();

    await fetch("http://localhost:7777", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "go_home" })
    }).catch(err => console.log("Fetch error:", err));

    console.log(`🍩 Donat trigger ke-${i}`);
  }

  console.log("✅ Batch selesai");

  isProcessingDonut = false;
  processDonutQueue(); // lanjut queue berikutnya
}

// processor (inti anti overlap)
async function processQueue() {
    if (isProcessing) return;
    isProcessing = true;

    while (queue.length > 0) {
        const task = queue.shift();
        try {
            await task();
        } catch (err) {
            console.log("Task error:", err);
        }

        // delay antar action (biar ga tabrakan)
        await delay(1000);
    }

    isProcessing = false;
}
  
tiktokLive.on("gift", data => {
  console.log(data.giftId)

  const targetGifts = [7934, 5655];
  const relog = [5660];

  if (targetGifts.includes(data.giftId) && data.repeatEnd === false) {
    addToQueue(async () => {
        playFah();

        await fetch("http://localhost:7777", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ 
                action: "go_home"
            })
        }).catch(err => console.log("Fetch error:", err));
    });
  }

  if(data.giftId === 8913){
    fetch("http://localhost:7777", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "open_app",
        package_name: "me.pou.app"
      })
    })
    .then(() => console.log("POU"))
    .catch(err => console.log("Uninstall error:", err));
  }

  if(relog.includes(data.giftId) && data.repeatEnd === false){
    fetch("http://localhost:7777", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "reset_app",
        package_name: "com.mobilelegends.mi"
      })
    })
    .then(() => console.log("✅ RELOG"))
    .catch(err => console.log("Relog error:", err));
  }

  if(data.giftId === 6267 || data.giftId === 7168 || data.giftId === 11046 || data.giftId === 6820){
    fetch("http://localhost:7777", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "uninstall_app",
        package_name: "com.mobilelegends.mi"
      })
    })
    .then(() => console.log("✅ UNINSTALL"))
    .catch(err => console.log("Uninstall error:", err));
  }

  if (data.giftId === ROSE_GIFT_ID && data.repeatEnd === true && data.repeatCount >= 5) {
    console.log("🌹 ROSE COMBO SELESAI:", data.repeatCount);

    for (let i = 0; i < data.repeatCount; i++) {
        addToQueue(async () => {
            playFah();

            await fetch("http://localhost:7777", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ 
                    action: "go_home"
                })
            }).catch(err => console.log("Fetch error:", err));
        });
    }
  }

  if (data.giftId === 5879 && data.repeatEnd === true) {

    const totalDonut = data.repeatCount;
    const totalTrigger = totalDonut * 30;

    console.log(`🍩 Menambahkan ${totalTrigger} trigger donat ke antrean utama`);
    for (let i = 1; i <= totalTrigger; i++) {
        addToQueue(async () => {
            console.log(`🍩 Donat trigger ke-${i}`);
            await playFah();
            await fetch("http://localhost:7777", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ action: "go_home" })
            }).catch(err => console.log("Fetch error:", err));
        });
    }
  }
});
