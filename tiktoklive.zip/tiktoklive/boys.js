const http = require('http');
const { exec } = require('child_process');


const PORT = 7777;
const ADB_PORT = '41023'; 
const ADB_HOST = '192.168.0.242';

const sendJson = (res, statusCode, payload) => {
    res.writeHead(statusCode, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(payload));
};

const server = http.createServer((req, res) => {
    if (req.method !== 'POST') {
        return sendJson(res, 405, { status: "Error", message: 'Gunakan method POST!' });
    }

    let body = '';
    req.on('data', chunk => { body += chunk.toString(); });

    req.on('end', () => {
        let data;
        try {
            data = JSON.parse(body);
        } catch (e) {
            return sendJson(res, 400, { status: 'Error', message: 'Format JSON tidak valid' });
        }

        const adbBase = `adb -s ${ADB_HOST}:${ADB_PORT}`;

        if (data.action === 'go_home') {
            const cmd = `${adbBase} shell am start -a android.intent.action.MAIN -c android.intent.category.HOME`;
            
            exec(cmd, (err, stdout, stderr) => {
                if (err) return sendJson(res, 500, { status: 'Error', message: err.message });
                console.log("Action: Back to Home");
                sendJson(res, 200, { status: 'Success', message: 'HP kembali ke Home' });
            });
        } 

        else if (data.action === 'uninstall_app') {
            const pkg = data.package_name;
            if (!pkg) return sendJson(res, 400, { status: 'Fail', message: 'Mana package_name-nya?' });

            const cmd = `${adbBase} shell "am force-stop ${pkg} && pm uninstall --user 0 ${pkg}"`;
            
            exec(cmd, (err, stdout, stderr) => {
                if (err) {
                    return sendJson(res, 500, { 
                        status: 'Error', 
                        message: `Gagal copot ${pkg}. Mungkin app sudah hilang atau koneksi putus.`,
                        detail: err.message 
                    });
                }
                
                console.log(`Action: Force Kill & Uninstall ${pkg}`);
                sendJson(res, 200, { 
                    status: 'Success', 
                    message: `Aplikasi ${pkg} berhasil ditutup paksa dan dicopot!`, 
                    output: stdout.trim() 
                });
            });
        }
        else if (data.action === 'reset_app') {
            const pkg = data.package_name;
            if (!pkg) return sendJson(res, 400, { status: 'Fail', message: 'Package name kosong!' });
        
            // 1️⃣ Force stop dulu
            const stopCmd = `${adbBase} shell am force-stop ${pkg}`;
        
            exec(stopCmd, (err) => {
                if (err) {
                    return sendJson(res, 500, { status: 'Error', message: `Gagal force stop ${pkg}` });
                }
        
                // 2️⃣ Launch ulang app
                const launchCmd = `${adbBase} shell monkey -p ${pkg} -c android.intent.category.LAUNCHER 1`;
        
                exec(launchCmd, (err2) => {
                    if (err2) {
                        return sendJson(res, 500, { status: 'Error', message: `Gagal launch ${pkg}` });
                    }
        
                    console.log(`Berhasil restart ${pkg}`);
                    sendJson(res, 200, { status: 'Success', message: `Aplikasi ${pkg} berhasil direstart!` });
                });
            });
        }
        else {
            sendJson(res, 400, { status: 'Fail', message: 'Action tidak dikenal (Gunakan: go_home, uninstall_app)' });
        }
    });
});

server.listen(PORT, '0.0.0.0', () => {
    console.log('=========================================');
    console.log(`Server Kontrol HP jalan di http://0.0.0.0:${PORT}`);
    console.log(`Target ADB Device: ${ADB_HOST}:${ADB_PORT}`);
    console.log('-----------------------------------------');
    console.log('Daftar Perintah JSON (Postman):');
    console.log('1. { "action": "go_home" }');
    console.log('2. { "action": "uninstall_app", "package_name": "com.target.app" }');
    console.log('=========================================');
});