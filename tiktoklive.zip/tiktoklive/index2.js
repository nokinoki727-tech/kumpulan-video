const { WebcastPushConnection } = require("tiktok-live-connector");
const sound = require("sound-play");
const path = require("path");

// ================= CONFIG =================
const TIKTOK_USERNAME = "aseptzy888";

const AUDIO_FAHS = path.join(__dirname, "sound", "fahh.mp3");
const AUDIO_HIDUP = path.join(__dirname, "sound", "montagem.mp3");
const AUDIO_SIU = path.join(__dirname, "sound", "nigg.mp3");
const AUDIO_SPONGE = path.join(__dirname, "sound", "ambatukam.mp3");

const FAHS_DURATION = 500;
const HIDUP_DURATION = 13000;
const SPONGE_DURATION = 6000;

const ROSE_GIFT_ID = 5655;
const HIDUP_GIFT_ID = 5269;
const I_HATE = 5333

// LIKE SETTINGS
const LIKE_THRESHOLD = 1;
const LIKE_SOUND_REPEAT = 2;
// ==========================================

// PRIORITY QUEUE
let giftQueue = [];
let likeQueue = [];

let isPlaying = false;

// LIKE COUNTER
let likeCounter = {};
let lastGiftUser = null;

// ================= TIKTOK CONNECT =================
const tiktokLive = new WebcastPushConnection(TIKTOK_USERNAME);

tiktokLive.connect()
  .then(() => console.log("✅ Connected to TikTok Live"))
  .catch(err => console.error("❌ Gagal connect:", err));

// ================= GIFT HANDLER =================
tiktokLive.on("gift", async data => {
  if (!data.repeatEnd) return;
  
  lastGiftUser = {
    username: data.uniqueId,
    avatar: data.profilePictureUrl // 🔥 AVATAR TIKTOK
  };

  // 🌹 ROSE
  if (data.giftId === ROSE_GIFT_ID) {
    console.log(`🌹 ${data.uniqueId} Rose x${data.repeatCount}`);
  
    for (let i = 1; i <= data.repeatCount; i++) {
      console.log(`🎬 Trigger video ${i}/${data.repeatCount}`);
  
      await fetch("http://localhost:3000/trigger/video");
      await new Promise(r => setTimeout(r, 900));
    }
  }

  // 🔥 HIDUP
  if (data.giftId === HIDUP_GIFT_ID) {
    console.log(`🔥 ${data.uniqueId} Gift Hidup x${data.repeatCount}`);

    for (let i = 1; i <= data.repeatCount; i++) {
      console.log(`🎬 Trigger video ${i}/${data.repeatCount}`);
  
      await fetch("http://localhost:3000/trigger/bahlil");
      await new Promise(r => setTimeout(r, 3800));
    }
  }

  //coffee
  if (data.giftId === I_HATE) {
    console.log(`${data.uniqueId} Coffee x${data.repeatCount}`);

    
    for (let i = 1; i <= data.repeatCount; i++) {
      console.log(`🎬 Trigger video ${i}/${data.repeatCount}`);
  
      await fetch("http://localhost:3000/trigger/video/montagem");
      await new Promise(r => setTimeout(r, 13000));
    }
  }

  // console.log(`🎁 GiftQueue: ${giftQueue.length} | 👍 LikeQueue: ${likeQueue.length}`);

  // if (!isPlaying) processQueue();
});

tiktokLive.on("like", data => {
  const user = data.uniqueId;

  if (!likeCounter[user]) likeCounter[user] = 0;
  likeCounter[user]++;

  if (likeCounter[user] >= LIKE_THRESHOLD) {
    likeCounter[user] = 0;

    likeQueue.push({
      audio: AUDIO_FAHS,
      duration: FAHS_DURATION,
      repeat: LIKE_SOUND_REPEAT
    });

    if (!isPlaying) processQueue();
  }
});

async function processQueue() {
  let job = null;

  if (giftQueue.length > 0) {
    job = giftQueue.shift(); // PRIORITAS
  } else if (likeQueue.length > 0) {
    job = likeQueue.shift();
  } else {
    isPlaying = false;
    console.log("🛑 Semua queue kosong");
    return;
  }

  isPlaying = true;

  for (let i = 1; i <= job.repeat; i++) {
    console.log(`🔊 Play ${i}/${job.repeat}`);
    sound.play(job.audio);
    await new Promise(r => setTimeout(r, job.duration));
  }

  processQueue();
}
