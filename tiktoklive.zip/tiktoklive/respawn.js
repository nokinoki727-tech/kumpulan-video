const fs = require("fs");
const { WebcastPushConnection } = require("tiktok-live-connector");
const sound = require("sound-play");
const path = require("path");
const AUDIO_FAHS = path.join(__dirname, "sound", "fahh.mp3");
const gTTS = require("gtts");

const tiktok = new WebcastPushConnection("jordy.el.gasing");

tiktok.connect().then(() => {
    console.log("Connected to TikTok Live");
});

let queue = 0;
let isProcessing = false;

async function playFah() {
    try {
      await sound.play(AUDIO_FAHS);
    } catch (err) {
      console.error("❌ Gagal play audio:", err);
    }
  }

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function processQueue() {
    if (isProcessing) return;
    isProcessing = true;

    while (queue > 0) {
        fs.writeFileSync("command.txt", "rose");
        queue--;

        // ⏱️ delay antar respawn (WAJIB)
        await sleep(1500);
    }

    isProcessing = false;
}

tiktok.on("gift", data => {
    console.log(data.giftId)
    console.log(data.giftName)
    if (data.giftId === 7934) {
        const fixedRepeat = 10;

        console.log(`Heart Me forced combo: x${fixedRepeat}`);

        queue += fixedRepeat;
        processQueue();
    }

    if (data.giftId === 5655 && data.repeatEnd === true) {
        console.log(`Rose combo: x${data.repeatCount}`);

        queue += data.repeatCount; // ⬅️ INI KUNCINYA
        processQueue();
    }
});

tiktok.on("follow", async (data) => {
    console.log(`🎉 ${data.uniqueId} just followed!`);
    await playFah();
});

async function speak(text) {
    return new Promise((resolve, reject) => {
        const filePath = path.join(__dirname, `tts-${Date.now()}.mp3`);
        const gtts = new gTTS(text, "id");

        gtts.save(filePath, async function (err) {
            if (err) return reject(err);

            try {
                await sound.play(filePath);
                fs.unlinkSync(filePath); // hapus setelah play
                resolve();
            } catch (err) {
                reject(err);
            }
        });
    });
}

tiktok.on("chat", async (data) => {
    console.log(`${data.uniqueId}: ${data.comment}`);

    try {
        await speak(`${data.comment}`);
    } catch (err) {
        console.error("TTS Error:", err);
    }
});