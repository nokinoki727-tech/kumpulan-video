const { WebcastPushConnection } = require("tiktok-live-connector");
const sound = require("sound-play");
const path = require("path");

const TIKTOK_USERNAME = "bgronwd";

const AUDIO_FAHS = path.join(__dirname, "sound", "fahh.mp3");

const ROSE_GIFT_ID = 5655;
const CORGY = 6267;
const HAND = 5660;
const DOUGH = 5879;
const HAT = 6427;
const GUN = 7168;
const ME = 7934;

const tiktokLive = new WebcastPushConnection(TIKTOK_USERNAME);

tiktokLive.connect()
  .then(() => console.log("✅ Connected to TikTok Live"))
  .catch(err => console.error("❌ Gagal connect:", err));

async function playFah() {
  try {
    await sound.play(AUDIO_FAHS);
  } catch (err) {
    console.error("❌ Gagal play audio:", err);
  }
}
  
tiktokLive.on("gift", data => {
  console.log(data.giftId)
  console.log(data.giftName)
  if(data.giftId === 7934){
    console.log("idk")
  }
  if(data.giftId === 5660){
    console.log("kontol")
  }
  if (!data.repeatEnd) return;

  if (data.giftId === ROSE_GIFT_ID) {
    console.log(`🌹 ${data.uniqueId} Rose x${data.repeatCount}`);
  
    for (let i = 1; i <= data.repeatCount; i++) {
      console.log("rose")
    }
  }
});

// //khusus debugging
// tiktokLive.on("gift", data => {
//   console.log("===== GIFT DEBUG =====");
//   console.log("User        :", data.uniqueId);
//   console.log("Gift ID     :", data.giftId);
//   console.log("Gift Name   :", data.giftName);
//   console.log("RepeatCount :", data.repeatCount);
//   console.log("RepeatEnd   :", data.repeatEnd);
//   console.log("DiamondCount:", data.diamondCount);
//   console.log("MsgID       :", data.msgId);
//   console.log(data.giftType)
//   console.log("======================\n");
// });

// tiktokLive.on("like", data => {
//   const user = data.uniqueId;

//   if (!likeCounter[user]) likeCounter[user] = 0;
//   likeCounter[user]++;

//   if (likeCounter[user] >= LIKE_THRESHOLD) {
//     likeCounter[user] = 0;

//     likeQueue.push({
//       audio: AUDIO_FAHS,
//       duration: FAHS_DURATION,
//       repeat: LIKE_SOUND_REPEAT
//     });

//     if (!isPlaying) processQueue();
//   }
// });

// tiktokLive.on("like", (data) => {
//   console.log("==== LIKE EVENT ====");
//   console.log("User ID      :", data.userId);
//   console.log("Username     :", data.uniqueId);
//   console.log("Nickname     :", data.nickname);
//   console.log("Total Likes  :", data.totalLikeCount);
//   console.log("Like Count   :", data.likeCount);
//   console.log("Profile Pic  :", data.profilePictureUrl);
//   console.log("Raw Data 👇");
//   console.log("====================\n");
// });

