const { exec } = require("child_process");

// full path ke adb.exe
const adbBase = `"C:\\platform-tools-latest-windows\\platform-tools\\adb.exe"`;

// device target
const device = "192.168.0.145:33769";

exec(`${adbBase} -s ${device} shell dumpsys window`, (err, stdout) => {
    if (err) return console.log(err);

    const line = stdout.split("\n").find(l => l.includes("mCurrentFocus"));
    if (!line) return console.log("Tidak ada mCurrentFocus");

    const match = line.match(/u0\s+([^\s]+)/);
    if (!match) return console.log("Format tidak cocok");

    const full = match[1]; // com.xxx/Activity
    const packageName = full.split("/")[0];

    console.log("Package:", packageName);
});